from setuptools import setup

setup(

    name="package_general_calc",
    version="1.0",
    description="general calculations package",
    author="Alberto Pila",
    packages=["Calculos"]

)