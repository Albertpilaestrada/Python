def rest(value1,value2):
    print("The rest is : {}".format(value1-value2))

def sum(value1,value2):
    print("The sum is : {}".format(value1+value2))

def multi(value1,value2):
    print("The multiplication is : {}".format(value1*value2))

def divi(value1,value2):
    print("The division is : {}".format(value1/value2))

def potency(base,exponent):
    print("The potency is : {}".format(base**exponent))

def round_(value):
    print("The round is : {}".format(round(value)))

